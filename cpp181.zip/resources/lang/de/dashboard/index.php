<?php

return [
    'search' => 'Suche nach Servern....',
    'no_matches' => 'Es stimmen keine Server mit den Kriterien überein.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Arbeitsspeicher',
];
