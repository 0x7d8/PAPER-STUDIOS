import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { ffa-solid fa-plus } from '@fortawesome/free-solid-svg-icons';
import EditSubuserModal from '@/components/server/users/EditSubuserModal';
import Button from '@/components/elements/Button';
import tw from 'twin.macro';

export default () => {
    const [ visible, setVisible ] = useState(false);

    return (
        <>
            <EditSubuserModal visible={visible} onModalDismissed={() => setVisible(false)}/>
            <Button onClick={() => setVisible(true)}>
                <FontAwesomeIcon icon={fa-plus} css={tw`mr-1`}/> Neuer Nutzer
            </Button>
        </>
    );
};
